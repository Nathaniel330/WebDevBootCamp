<?php
namespace App\Models;
class Products{
 public static function getAll(){
    return [
        // mess
        // productImagesArray[0] must be the same as productImage
        // productName must not contain apostrophe, space, --used in bs-target carousel
        // database- ish?
        [
            'productId'=> 1,
            'productShop' => 'LazMall',
            'productName'=> 'demo',
            'productDescription' => 'Description1',
            'productPrice' => 100,
            'productDiscountInteger' => 50,
            'productImage'=> 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/640px-Image_created_with_a_mobile_phone.png',
            'productImagesArray' => array('https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/640px-Image_created_with_a_mobile_phone.png','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSe8IQrpci_lb0KcKSoTutxeFX25kDxHk2SfcDguEUp&s'),
            'productSellCount' => 99,
            'sellerLocation' => 'Tokyo'
        ],
        [
            'productId'=> 2,
            'productShop' => 'LazMall',
            'productName'=> 'name2',
            'productDescription' => 'Descript. 2',
            'productPrice' => 200,
            'productDiscountInteger' => 20,
            'productImage'=> 'https://cdn.pixabay.com/photo/2016/06/29/16/31/numbers-1487225_960_720.png',
            'productImagesArray' => array('https://cdn.pixabay.com/photo/2016/06/29/16/31/numbers-1487225_960_720.png','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 175,
            'sellerLocation' => 'Mumbai'
        ],
        [
            'productId'=> 3,
            'productShop' => 'LazMall',
            'productName'=> 'PlayStation3',
            'productDescription' => 'version 2017 slightly used includes 3 games',
            'productPrice' => 333,
            'productDiscountInteger' => 13,
            'productImage'=> 'https://img.clasf.com.br/2020/01/15/playstation-3-slim-2-controles-20200115173436.0219260015.jpg',
            'productImagesArray' => array('https://img.clasf.com.br/2020/01/15/playstation-3-slim-2-controles-20200115173436.0219260015.jpg','https://cdn.create.vista.com/api/media/small/53497761/stock-photo-game-controller'),
            'productSellCount' => 3,
            'sellerLocation' => 'Reykjavik'
        ],
        [
            'productId'=> 4,
            'productShop' => 'LazMall',
            'productName'=> "RubiksCube",
            'productDescription' => '3x3 mech-joint ez-rotate',
            'productPrice' => 200,
            'productDiscountInteger' => 5,
            'productImage'=> 'https://upload.wikimedia.org/wikipedia/commons/3/35/2020-05-13_17_14_20_One_side_of_a_scrambled_Rubik%27s_Cube_in_the_Franklin_Farm_section_of_Oak_Hill%2C_Fairfax_County%2C_Virginia.jpg',
            'productImagesArray' => array('https://upload.wikimedia.org/wikipedia/commons/3/35/2020-05-13_17_14_20_One_side_of_a_scrambled_Rubik%27s_Cube_in_the_Franklin_Farm_section_of_Oak_Hill%2C_Fairfax_County%2C_Virginia.jpg','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 1,
            'sellerLocation' => 'Inaba'
        ],
        [
            'productId'=> 5,
            'productShop' => 'LazMall',
            'productName'=> "PlayingCards",
            'productDescription' => 'max luck guaranteed win(play atleast 10 matches)',
            'productPrice' => 20,
            'productDiscountInteger' => 1,
            'productImage'=> 'https://www.thesprucecrafts.com/thmb/O6rvJgXDe_nnMQzSuNUTNdG_5-U=/fit-in/800x415/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/bicyclebestplayingcards-d39a575fcbdd4b278806ebe855663ee9.jpg',
            'productImagesArray' => array('https://www.thesprucecrafts.com/thmb/O6rvJgXDe_nnMQzSuNUTNdG_5-U=/fit-in/800x415/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/bicyclebestplayingcards-d39a575fcbdd4b278806ebe855663ee9.jpg','https://previews.123rf.com/images/michaeldb/michaeldb1405/michaeldb140500014/28458221-royal-flush-hearts-five-card-poker-hand-playing-cards-deck.jpg?fj=1'),
            'productSellCount' => 66,
            'sellerLocation' => 'Karachi'
        ], 
        [
            'productId'=> 6,
            'productShop' => 'LazMall',
            'productName'=> "Go",
            'productDescription' => 'item6 description',
            'productPrice' => 30,
            'productDiscountInteger' => 0,
            'productImage'=> 'https://america.cgtn.com/wp-content/uploads/2019/01/Luis-Chirino.jpg',
            'productImagesArray' => array('https://america.cgtn.com/wp-content/uploads/2019/01/Luis-Chirino.jpg','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 50,
            'sellerLocation' => 'Sao Paolo'
        ],  
        [
            'productId'=> 7,
            'productShop' => 'LazMall',
            'productName'=> "abacus",
            'productDescription' => 'item7 description',
            'productPrice' => 100,
            'productDiscountInteger' => 20,
            'productImage'=> 'https://cdn.shopify.com/s/files/1/2158/5455/products/Abacuspic12048x2048_2048x.png?v=1646261138',
            'productImagesArray' => array('https://cdn.shopify.com/s/files/1/2158/5455/products/Abacuspic12048x2048_2048x.png?v=1646261138','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 34,
            'sellerLocation' => 'Fang Cheng'
        ],    
        [
            'productId'=> 8,
            'productShop' => 'LazMall',
            'productName'=> "bonsai",
            'productDescription' => 'item7 description',
            'productPrice' => 75,
            'productDiscountInteger' => 15,
            'productImage'=> 'https://cdn.britannica.com/65/123265-050-F0F8FD6B/bonsai-cypress-National-Bonsai-and-Penjing-Museum.jpg',
            'productImagesArray' => array('https://cdn.britannica.com/65/123265-050-F0F8FD6B/bonsai-cypress-National-Bonsai-and-Penjing-Museum.jpg','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 197,
            'sellerLocation' => 'Panama'
        ],
        [
            'productId'=> 9,
            'productShop' => 'LazMall',
            'productName'=> "mask-Oni",
            'productDescription' => 'item7 description',
            'productPrice' => 66,
            'productDiscountInteger' => 6,
            'productImage'=> 'https://i.redd.it/9l2uiuble6w41.jpg',
            'productImagesArray' => array('https://i.redd.it/9l2uiuble6w41.jpg','https://s3.amazonaws.com/static.graphemica.com/glyphs/i500s/000/009/009/original/2161-500x500.png?1275323171'),
            'productSellCount' => 6,
            'sellerLocation' => 'Akibahara'
        ],   
        [
            'productId'=> 10,
            'productShop' => 'LazMall',
            'productName'=> "mystery_box",
            'productDescription' => '???',
            'productPrice' => 1098.9,
            'productDiscountInteger' => 9,
            'productImage'=> 'https://www.bobobird.com/wp-content/uploads/2020/07/mystery-box.jpg',
            'productImagesArray' => array('https://www.bobobird.com/wp-content/uploads/2020/07/mystery-box.jpg','https://ewr9gftwh9h.exactdn.com/wp-content/uploads/2018/01/Question-Mark.png?strip=all&lossy=1&resize=195%2C195'),
            'productSellCount' => '???',
            'sellerLocation' => '???'
        ],                                                
    ];
 }
 public static function getById($productId){
    $Products = self::getAll();
    foreach($Products as $product){
        if($product['productId'] == $productId){
            return $product;
        }
    }
 }
}
?>