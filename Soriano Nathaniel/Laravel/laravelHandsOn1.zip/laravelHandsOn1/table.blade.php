<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Hands On 1</title>
    <style>
        .table {
            text-align: center;
        }
        table {
            table-layout:fixed;
            width: 1111px;
            margin: 20px 0;
        }
        td {
            border: 1px solid black;
            width: 150px;
            padding: 5px;
            overflow-wrap: break-word;
        }
        img {
            width: 100%;
            height: 150px;

        }
    </style>
</head>
<body>
    <div>Create a table of your top 5 restaurant with their Name, Location, website/social media and Picture.</div>
    <div class="table">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Website/Social Media</th>
                    <th>Picture</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Cluckin' Bell</td>
                    <td>GTA San Andreas</td>
                    <td><a href="https://gta.fandom.com/wiki/Cluckin%27_Bell">https://gta.fandom.com/wiki/Cluckin%27_Bell</a></td>
                    <td><img src="https://scontent.fmnl17-4.fna.fbcdn.net/v/t1.18169-9/13920716_1414781051870885_3191002580500228034_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=9267fe&_nc_ohc=3fKHLJB-6GYAX-olfsU&_nc_ht=scontent.fmnl17-4.fna&oh=00_AT8FaVEXs1vhFXPvYjtCisthbWzZaqB4YB-eEZuN9c3BwQ&oe=636BE107" alt=""></td>
                </tr>
                <tr>
                    <td>Seventh Heaven</td>
                    <td>Final Fantasy Seven</td>
                    <td><a href="https://finalfantasy.fandom.com/wiki/Seventh_Heaven_(Final_Fantasy_VII)#:~:text=Seventh%20Heaven%2C%20alternatively%20spelled%207th,specifically%20in%20Final%20Fantasy%20VII.">https://finalfantasy.fandom.com/wiki/Seventh_Heaven_(Final_Fantasy_VII)#:~:text=Seventh%20Heaven%2C%20alternatively%20spelled%207th,specifically%20in%20Final%20Fantasy%20VII.</a></td>
                    <td><img src="https://blenderartists.org/uploads/default/original/4X/8/5/7/8570ad77e92e53be7e150dfaf0145bdd1e11d444.jpeg" alt=""></td>
                </tr>
                <tr>
                    <td>Hunter's Bar</td>
                    <td>1 Chome-3-16 Kabukicho, Shinjuku City, Tokyo 160-0021, Japan, Level 1</td>
                    <td><a href="https://en.japantravel.com/tokyo/hunters-bar/59077">https://en.japantravel.com/tokyo/hunters-bar/59077</a></td>
                    <td><img src="https://a2.cdn.japantravel.com/photo/59077-199074/738x491.8798828125!/tokyo-hunters-bar-199074.jpg" alt=""></td>
                </tr>
                <tr>
                    <td>Kansas City Barbeque</td>
                    <td>600 W. Harbor Drive San Diego, CA</td>
                    <td><a href="https://kcbbq.net/#:~:text=Kansas%20City%20Barbeque%20is%20a,in%20the%20film%20Top%20Gun.">https://kcbbq.net/#:~:text=Kansas%20City%20Barbeque%20is%20a,in%20the%20film%20Top%20Gun.</a></td>
                    <td><img src="https://static.spotapps.co/spots/8b/5d47007ed511e891668f75e5799495/full" alt=""></td>
                </tr>
                <tr>
                    <td>7-eleven</td>
                    <td>Anywhere</td>
                    <td><a href="https://www.7-eleven.com.ph/">https://www.7-eleven.com.ph/</a></td>
                    <td><img src="https://coconuts.co/wp-content/uploads/2016/11/seven.jpg" alt=""></td>
                </tr>
            </tbody>
        </table>
    </div>
    
</body>
</html>