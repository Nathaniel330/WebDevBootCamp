<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\Products;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//get all Products
Route::get('/products', function () {
    return view('productAll', [
        'title'=>"Product List",
        'products'=>Products::getAll()
    ]);
});
//get Products by productId
Route::get('/products/{productId}', function ($productId) {
    return view('product', [
        'title'=>"View Product:",
        'product'=>Products::getById($productId)
    ]);
});

Route::get('/table', function () {
    return view('table');
});