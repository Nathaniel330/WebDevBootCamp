
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <title>Laravel Hands On 2</title>
<style>
    .card-img-top{
        width: 100%;
        height: 200px;
    }
    .carousel-indicators .indicator-img{
       
        border: 1px solid grey;
    }
    .indicator-img {
        height: 40px;
    }
    .totalPrice {
        color: darkorange;
    }
</style>
</head>
<body class="text-center text-sm-start p-2">
<h1 class="mb-4">Title: {{$title}}</h1>

<div class="d-flex justify-content-center flex-wrap gap-3">
@foreach($products as $product)
<div class="card col-8 col-sm-7 col-md-4 col-xxl-2 d-flex flex-column align-items-center">
    <div id="{{$product['productName']}}" class="carousel slide" style="width:250px" data-bs-ride="true">
        <div class="carousel-indicators justify-content-start ms-0 ps-2">
            @for ($i = 0; $i < count($product['productImagesArray']); $i++)
                <button type="button" data-bs-target="#{{$product['productName']}}" data-bs-slide-to="{{$i}}" class="active" aria-current="true" aria-label="Slide 1">
                    <img
                        src="{{$product['productImagesArray'][$i]}}" 
                        class="indicator-img d-block w-100"
                        alt="...">
                </button>
            @endfor
        </div>
        <div class="carousel-inner">
            @for ($i = 0; $i < count($product['productImagesArray']); $i++)
                
            <div class="carousel-item text-center p-2 @if ($product['productImagesArray'][$i] == $product['productImagesArray'][0] ) active @endif" style="width:250px height: 250px;">
                <a href="/products/{{$product['productId']}}">
                    <img src="{{$product['productImagesArray'][$i]}}" class="d-block w-100"  style="height:250px" alt="...">
                </a>
            </div>
            @endfor
        </div>
        <div style="height:27px"></div>
    </div>
    <div class="card-body text-start pt-4">
        <div class="card-text overflow-hidden pt-1" style="height:50px">
            <span class="bg-danger p-1 border rounded text-light">{{$product['productShop']}} </span>{{$product['productName']}} {{$product['productDescription']}}
        </div>
        <div class="card-text text-start mb-4">
            <?php $discount_float = $product['productDiscountInteger'] / 100 ?>
            <?php $discount_total = $discount_float * $product['productPrice'] ?>
            <?php $product_total_price = $product['productPrice'] - $discount_total?>
            <span class="totalPrice fw-bold fs-2">${{$product_total_price}}</span><br>
            <div class="d-flex justify-content-start gap-1">
                <div><del>${{$product['productPrice']}}</del></div>
                <div>-{{$product['productDiscountInteger']}}%</div>
            </div>
        </div>
        
        <div class="d-flex justify-content-between form-text">
            <div>⭐⭐⭐({{$product['productSellCount']}})</div>
            <div>{{$product['sellerLocation']}}</div>
        </div>

    </div>
</div>
@endforeach
</div>  


</body>
</html>